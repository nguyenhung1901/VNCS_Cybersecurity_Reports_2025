package controller;

import view.LoginView;

public class LoginController {
    private LoginView loginView;

    public LoginController(LoginView loginView) {
        this.loginView = loginView;

        // Gắn LoginActionListener cho các nút
        LoginActionListener actionListener = new LoginActionListener(loginView);
        loginView.getLoginButton().addActionListener(actionListener);
        loginView.getExitButton().addActionListener(actionListener);
    }
}
