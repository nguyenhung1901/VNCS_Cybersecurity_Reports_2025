package controller;

import view.Giaodien;
import view.LoginView;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginActionListener implements ActionListener {
    private LoginView loginView;

    public LoginActionListener(LoginView loginView) {
        this.loginView = loginView;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == loginView.getLoginButton()) {
            String username = loginView.getUsername();
            String password = loginView.getPassword();

            // Kiểm tra đăng nhập
            if (username.equals("admin") && password.equals("admin")) {
                loginView.showMessage("Đăng nhập thành công!");

                // Đóng giao diện đăng nhập
                loginView.dispose();

                // Mở giao diện chính
                new Giaodien();
            } else {
                loginView.showMessage("Tên người dùng hoặc mật khẩu không đúng.");
            }
        } else if (e.getSource() == loginView.getExitButton()) {
            System.exit(0);
        }
    }
}

