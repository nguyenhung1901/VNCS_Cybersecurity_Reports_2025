
package controller;

import java.awt.event.ActionListener;
import model.Ds_monan;
import model.Mon_an;
import view.Mang_ve;
import JDBCConnection.*;

import javax.swing.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Date;

public class MangveController {
    private Mang_ve mangVe; // Lớp view
    private HashMap<String, Integer> cart; // Giỏ hàng
    private int totalAmount = 0; // Tổng số tiền

    public MangveController(Mang_ve mangVe) {
        this.mangVe = mangVe;
        this.cart = new HashMap<>();
    }

    // Phương thức xử lý khi chọn món
    public ActionListener createItemButtonListener(Mon_an mon) {
        return e -> {
            String itemName = mon.getName();
            if (cart.containsKey(itemName)) {
                cart.put(itemName, cart.get(itemName) + 1); // Tăng số lượng
            } else {
                cart.put(itemName, 1); // Thêm món ăn mới vào giỏ
            }
            totalAmount += mon.getPrice(); // Cộng tiền vào tổng số tiền
            updateOrderList(); // Cập nhật danh sách giỏ hàng
            updateTotalLabel(); // Cập nhật tổng tiền
        };
    }

    // Hàm cập nhật tổng tiền
    private void updateTotalLabel() {
        mangVe.updateTotalLabel(totalAmount); // Gọi phương thức cập nhật tổng tiền trong mangVe
    }
    
    // Hàm cập nhật danh sách giỏ hàng hiển thị
    private void updateOrderList() {
        mangVe.updateOrderList(cart); // Gọi phương thức cập nhật danh sách trong mangVe
    }

    // Phương thức thanh toán và lưu thông tin vào cơ sở dữ liệu
    public void checkout() {
        if (!cart.isEmpty()) {
            // Lưu thông tin vào cơ sở dữ liệu
            saveOrderToDatabase();
            JOptionPane.showMessageDialog(mangVe, "Thanh toán thành công!");

            cart.clear(); // Xóa giỏ hàng sau khi thanh toán
            totalAmount = 0; // Reset tổng tiền
            updateOrderList(); // Cập nhật danh sách hiển thị
            updateTotalLabel(); // Cập nhật tổng tiền
        } else {
            JOptionPane.showMessageDialog(mangVe, "Giỏ hàng đang trống.");
        }
    }
    public void clearCart() {
    cart.clear();  // Xóa tất cả các món trong giỏ hàng
    totalAmount = 0;
    mangVe.updateOrderList(cart); // Cập nhật lại danh sách giỏ hàng trên giao diện
    mangVe.updateTotalLabel(totalAmount); // Cập nhật lại tổng tiền là 0
}

    // Hàm lưu đơn hàng vào cơ sở dữ liệu
    private void saveOrderToDatabase() {
        String query = "INSERT INTO orderfood (orderdate, totalamount, payment) VALUES (?, ?, ?)";
        try (Connection conn = JConnection.getJDBCConection()) {
            if (conn != null) {
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setDate(1, new java.sql.Date(new Date().getTime())); // Lấy ngày hiện tại
                stmt.setString(2, String.valueOf(totalAmount)); // Chuyển tổng tiền sang chuỗi
                stmt.setString(3, "Đã thanh toán"); // Đặt trạng thái thanh toán là "Đã thanh toán"

                int rowsAffected = stmt.executeUpdate(); // Thực thi câu lệnh INSERT
            } else {
                System.out.println("Không thể kết nối đến cơ sở dữ liệu.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
