
package view;

import JDBCConnection.JConnection;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Chinh_sua_menu extends JPanel {
    private JTextField nameField, priceField, searchField;
    private JButton addButton, deleteButton, updateButton, searchButton, refreshButton;
    private JTextArea foodListArea;

    public Chinh_sua_menu() {
        // Sử dụng GridBagLayout để sắp xếp các thành phần
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 10, 10, 10); // Tăng khoảng cách giữa các phần tử
        setBackground(new Color(240, 240, 240)); // Màu nền cho panel chính

        // Panel nhập liệu thêm hoặc sửa món ăn
        JPanel inputPanel = new JPanel(new GridLayout(3, 2, 10, 10)); // Tăng khoảng cách giữa các ô trong GridLayout
        inputPanel.setBorder(BorderFactory.createTitledBorder("Thêm/Sửa món ăn"));
        inputPanel.setBackground(new Color(255, 255, 255)); // Màu nền cho panel nhập liệu
        nameField = new JTextField();
        nameField.setPreferredSize(new Dimension(200, 30)); // Tăng kích thước của ô nhập liệu
        priceField = new JTextField();
        priceField.setPreferredSize(new Dimension(200, 30)); // Tăng kích thước của ô nhập liệu
        inputPanel.add(new JLabel("Tên món ăn:"));
        inputPanel.add(nameField);
        inputPanel.add(new JLabel("Giá:"));
        inputPanel.add(priceField);

        // Panel nút thêm, xóa và sửa
        addButton = createStyledButton("Thêm");
        deleteButton = createStyledButton("Xóa");
        updateButton = createStyledButton("Sửa");

        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.setBackground(new Color(255, 255, 255)); // Màu nền cho panel nút
        buttonPanel.add(addButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(updateButton);

        // Panel tìm kiếm món ăn
        JPanel searchPanel = new JPanel(new FlowLayout());
        searchPanel.setBorder(BorderFactory.createTitledBorder("Tìm kiếm món ăn"));
        searchPanel.setBackground(new Color(255, 255, 255)); // Màu nền cho panel tìm kiếm
        searchField = new JTextField(15); // Tăng kích thước ô tìm kiếm
        searchButton = createStyledButton("Tìm kiếm");
        refreshButton = createStyledButton("Làm mới");
        searchPanel.add(new JLabel("Tên món ăn:"));
        searchPanel.add(searchField);
        searchPanel.add(searchButton);
        searchPanel.add(refreshButton);

        // Danh sách món ăn
        foodListArea = new JTextArea(12, 40); // Tăng số dòng và chiều rộng của JTextArea
        foodListArea.setEditable(false);
        foodListArea.setBackground(new Color(240, 240, 240)); // Màu nền cho JTextArea
        JScrollPane scrollPane = new JScrollPane(foodListArea);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Danh sách món ăn"));

        // Định nghĩa vị trí cho các thành phần trong panel chính
        gbc.gridx = 0;
        gbc.gridy = 0;
        add(inputPanel, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        add(buttonPanel, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        add(searchPanel, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.fill = GridBagConstraints.BOTH;
        add(scrollPane, gbc);

        // Hiển thị danh sách món ăn ban đầu
        refreshFoodList();

        // Thêm hành động cho các nút
        addButton.addActionListener(e -> addFood());
        deleteButton.addActionListener(e -> deleteFood());
        updateButton.addActionListener(e -> updateFood());
        searchButton.addActionListener(e -> searchFood());
        refreshButton.addActionListener(e -> refreshFoodList());
    }

    // Chức năng làm mới danh sách món ăn
    private void refreshFoodList() {
        foodListArea.setText("");
        try (Connection conn = JConnection.getJDBCConection()) {
            String sql = "SELECT * FROM food";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                foodListArea.append(rs.getString("namefood") + " - " + rs.getInt("prices") + " VND\n");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Chức năng thêm món ăn
    private void addFood() {
        String name = nameField.getText();
        String priceStr = priceField.getText();
        if (validateInput(name, priceStr)) {
            try (Connection conn = JConnection.getJDBCConection()) {
                // Kiểm tra món ăn đã tồn tại chưa
                String checkSql = "SELECT * FROM food WHERE namefood = ?";
                PreparedStatement checkPs = conn.prepareStatement(checkSql);
                checkPs.setString(1, name);
                ResultSet rs = checkPs.executeQuery();

                if (rs.next()) {
                    // Nếu món ăn đã tồn tại, hiển thị thông báo
                    JOptionPane.showMessageDialog(this, "Món ăn đã tồn tại trong cơ sở dữ liệu");
                } else {
                    // Nếu món ăn chưa tồn tại, thực hiện thêm mới
                    String sql = "INSERT INTO food (namefood, prices) VALUES (?, ?)";
                    PreparedStatement ps = conn.prepareStatement(sql);
                    ps.setString(1, name);
                    ps.setInt(2, Integer.parseInt(priceStr));
                    ps.executeUpdate();
                    JOptionPane.showMessageDialog(this, "Thêm món ăn thành công");
                    refreshFoodList();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            // Xóa giá trị đã nhập vào các trường
            nameField.setText("");
            priceField.setText("");
        }
    }

    // Chức năng xóa món ăn
    private void deleteFood() {
        String name = nameField.getText();
        if (!name.isEmpty()) {
            try (Connection conn = JConnection.getJDBCConection()) {
                String sql = "DELETE FROM food WHERE namefood = ?";
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setString(1, name);
                int rowsAffected = ps.executeUpdate();
                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(this, "Xóa món ăn thành công");
                } else {
                    JOptionPane.showMessageDialog(this, "Không tìm thấy món ăn cần xóa");
                }
                refreshFoodList();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            // Xóa giá trị đã nhập vào các trường
            nameField.setText("");
            priceField.setText("");
        } else {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập tên món ăn cần xóa");
        }
    }

    // Chức năng sửa món ăn
    private void updateFood() {
        String name = nameField.getText();
        String priceStr = priceField.getText();
        if (validateInput(name, priceStr)) {
            try (Connection conn = JConnection.getJDBCConection()) {
                String sql = "UPDATE food SET prices = ? WHERE namefood = ?";
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setInt(1, Integer.parseInt(priceStr));
                ps.setString(2, name);
                int rowsAffected = ps.executeUpdate();
                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(this, "Sửa món ăn thành công");
                } else {
                    JOptionPane.showMessageDialog(this, "Không tìm thấy món ăn cần sửa");
                }
                refreshFoodList();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            // Xóa giá trị đã nhập vào các trường
            nameField.setText("");
            priceField.setText("");
        }
    }

    // Chức năng tìm kiếm món ăn 
    private void searchFood() {
        String name = searchField.getText();
        foodListArea.setText("");
        if (!name.isEmpty()) {
            try (Connection conn = JConnection.getJDBCConection()) {
                // Dùng hàm LOWER() để tìm kiếm không phân biệt chữ hoa chữ thường
                String sql = "SELECT * FROM food WHERE LOWER(namefood) LIKE LOWER(?)";
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setString(1, "%" + name + "%");
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    foodListArea.append(rs.getString("namefood") + " - " + rs.getInt("prices") + " VND\n");
                }
                if (foodListArea.getText().isEmpty()) {
                    foodListArea.append("Không tìm thấy món ăn");
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else {
            refreshFoodList();
        }
    }

    // Kiểm tra dữ liệu nhập vào
    private boolean validateInput(String name, String priceStr) {
        if (name.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Tên món ăn không được để trống");
            return false;
        }
        if (priceStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Giá món ăn không được để trống");
            return false;
        }
        try {
            Integer.parseInt(priceStr);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Giá phải là một số");
            return false;
        }
        return true;
    }

    // Hàm tạo nút với kiểu dáng đẹp
    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(new Color(0, 123, 255)); // Màu nền
        button.setForeground(Color.WHITE); // Màu chữ
        button.setFont(new Font("Arial", Font.BOLD, 10)); // Giảm kích thước font
        button.setBorder(BorderFactory.createLineBorder(new Color(0, 123, 255))); // Viền nút
        button.setPreferredSize(new Dimension(70, 25)); // Giảm kích thước nút
        button.setFocusPainted(false); // Loại bỏ viền khi chọn nút
        return button;
    }
}

