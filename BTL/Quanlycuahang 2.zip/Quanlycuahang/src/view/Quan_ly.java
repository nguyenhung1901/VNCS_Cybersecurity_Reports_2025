package view;

import java.awt.BorderLayout;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Quan_ly extends JPanel {

    public Quan_ly() {
        // Thiết lập layout cho giao diện quản lý
        this.setLayout(new BorderLayout());

        // Tạo MenuBar
        JMenuBar menuBar = new JMenuBar();

        // Tạo các mục menu
        JMenu menuQuanLy = new JMenu("Quản lý");

        // Tạo các lựa chọn trong menu Quản lý
        JMenuItem lichSuGiaoDichItem = new JMenuItem("Lịch sử giao dịch");
        JMenuItem themMonItem = new JMenuItem("Thêm món");
        JMenuItem dangXuatItem = new JMenuItem("Đăng xuất");
        // them phan thong ke theo tuan, thang
        JMenuItem thongKeItem = new JMenuItem("Thống kê");
        // Thêm các lựa chọn vào menu Quản lý
        menuQuanLy.add(lichSuGiaoDichItem);
        menuQuanLy.add(themMonItem);
        menuQuanLy.addSeparator(); // Tạo đường phân cách
        menuQuanLy.add(dangXuatItem);

        // Thêm menu Quản lý vào MenuBar
        menuBar.add(menuQuanLy);

        // Thêm MenuBar vào giao diện quản lý
        this.add(menuBar, BorderLayout.NORTH);

        // Thêm sự kiện cho các lựa chọn trong menu

        // Sự kiện khi chọn Lịch sử giao dịch
        lichSuGiaoDichItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Hiển thị hoặc xử lý logic liên quan đến lịch sử giao dịch
                JOptionPane.showMessageDialog(null, "Hiển thị Lịch sử giao dịch");
            }
        });

        // Sự kiện khi chọn Thêm món
        themMonItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Hiển thị hoặc xử lý logic liên quan đến thêm món
                JOptionPane.showMessageDialog(null, "Hiển thị giao diện Thêm món");
            }
        });

        // Sự kiện khi chọn Đăng xuất
        dangXuatItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Xử lý logic đăng xuất, quay lại giao diện đăng nhập hoặc thoát
                JOptionPane.showMessageDialog(null, "Bạn đã đăng xuất!");
                // Có thể đóng chương trình hoặc quay về giao diện chính
                System.exit(0); // Ví dụ: đóng chương trình
            }
        });
    }
}
