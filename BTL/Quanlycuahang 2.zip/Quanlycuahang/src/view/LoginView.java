
package view;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;

public class LoginView extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JButton exitButton;

    public LoginView() {
        this.setTitle("Đăng Nhập");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLayout(new BorderLayout());

        // Tạo panel chứa hình ảnh
        JPanel imagePanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                try {
                    // Đọc và vẽ hình ảnh
                    BufferedImage image = ImageIO.read(getClass().getResource("anh3.png"));
                    g.drawImage(image, 0, 0, this);  // Vẽ hình ảnh lên panel
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        };
        imagePanel.setPreferredSize(new Dimension(220, 220));  // Điều chỉnh kích thước hình ảnh
        imagePanel.setBackground(Color.LIGHT_GRAY); // Có thể thêm màu nền để dễ nhận diện

        // Tạo panel cho form đăng nhập
        JPanel formPanel = new JPanel(new GridLayout(4, 2, 10, 10));
        formPanel.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));  // Điều chỉnh khoảng cách xung quanh

        // Thêm các thành phần vào form
        formPanel.add(new JLabel("Tên người dùng:"));
        usernameField = new JTextField();
        usernameField.setPreferredSize(new Dimension(100, 10));  // Điều chỉnh kích thước JTextField
        formPanel.add(usernameField);

        formPanel.add(new JLabel("Mật khẩu:"));
        passwordField = new JPasswordField();
        passwordField.setPreferredSize(new Dimension(100, 10));  // Điều chỉnh kích thước JTextField
        formPanel.add(passwordField);

        // Tạo panel cho các nút
        JPanel buttonPanel = new JPanel();
        
        // Tạo nút Đăng nhập
        loginButton = new JButton("Đăng nhập");
        customizeButton(loginButton, new Color(34, 139, 34), new Color(255, 255, 255)); // Màu xanh lá và chữ trắng

        // Tạo nút Thoát
        exitButton = new JButton("Thoát");
        customizeButton(exitButton, new Color(255, 69, 0), new Color(255, 255, 255)); // Màu đỏ và chữ trắng

        // Cải thiện khoảng cách giữa các nút
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));  // Sắp xếp nút vào giữa với khoảng cách nhỏ hơn

        // Thêm ActionListener cho nút Thoát
        exitButton.addActionListener(e -> System.exit(0));

        buttonPanel.add(loginButton);
        buttonPanel.add(exitButton);

        // Tạo panel tổng hợp chứa form và các nút
        JPanel loginPanel = new JPanel();
        loginPanel.setLayout(new BoxLayout(loginPanel, BoxLayout.Y_AXIS)); // Sắp xếp theo chiều dọc
        loginPanel.add(formPanel);
        loginPanel.add(Box.createVerticalStrut(10));  // Thêm một khoảng cách nhỏ giữa form và các nút
        loginPanel.add(buttonPanel);

        // Thêm các panel vào frame
        this.add(imagePanel, BorderLayout.WEST); // Thêm hình ảnh vào phía trái
        this.add(loginPanel, BorderLayout.CENTER); // Thêm form và nút vào giữa

        // Sử dụng pack() để tự động điều chỉnh kích thước cửa sổ
        this.pack();
        
        // Đảm bảo rằng cửa sổ được hiển thị ở giữa màn hình
        this.setLocationRelativeTo(null); // Đặt cửa sổ ở giữa màn hình

        this.setVisible(true);
    }

    // Hàm tùy chỉnh cho nút
    private void customizeButton(JButton button, Color bgColor, Color fgColor) {
        button.setFont(new Font("Arial", Font.BOLD, 14)); // Thay đổi font size cho nút
        button.setBackground(bgColor);
        button.setForeground(fgColor);
        button.setFocusPainted(false); // Không có đường viền khi chọn
        button.setPreferredSize(new Dimension(120, 35)); // Điều chỉnh kích thước nút nhỏ hơn
        button.setBorder(BorderFactory.createLineBorder(fgColor)); // Đường viền cho nút

        // Hover effect
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(bgColor.darker()); // Màu khi hover
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(bgColor); // Trở lại màu ban đầu
            }
        });
    }

    public String getUsername() {
        return usernameField.getText();
    }

    public String getPassword() {
        return new String(passwordField.getPassword());
    }

    public JButton getLoginButton() {
        return loginButton;
    }

    public JButton getExitButton() {
        return exitButton;
    }

    public void showMessage(String message) {
        JOptionPane.showMessageDialog(this, message);
    }
}
