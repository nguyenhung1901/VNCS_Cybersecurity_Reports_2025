//
//package view;
//
//import javax.swing.*;
//import java.awt.*;
//import java.awt.event.*;
//import model.*;
//import controller.*;
//
//public class Giaodien extends JFrame {
//    private CardLayout cardLayout;
//    private JPanel mainPanel;
//    private Ds_monan dsMonan;
//
//    // Nút lựa chọn
//    private JButton mangVeButton;
//    private JButton taiChoButton;
//    private JButton quanLyButton;
//
//    // PopupMenu để hiển thị các mục con dưới nút Quản lý
//    private JPopupMenu quanLyMenu;
//
//    public Giaodien() {
//        // Thiết lập khung chính
//        this.setTitle("Giao diện chính");
//        this.setSize(1000, 700);
//        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        this.setLocationRelativeTo(null);
//        this.setLayout(new BorderLayout());
//
//        // Tạo các nút lựa chọn trên cùng
//        mangVeButton = new JButton("Mang về");
//        taiChoButton = new JButton("Tại chỗ");
//        quanLyButton = new JButton("Quản lý");
//
//        // Panel chứa các nút lựa chọn
//        JPanel menuPanel = new JPanel(new GridLayout(1, 3));
//        menuPanel.add(mangVeButton);
//        menuPanel.add(taiChoButton);
//        menuPanel.add(quanLyButton);
//
//        // Thêm panel menu vào trên cùng của giao diện
//        this.add(menuPanel, BorderLayout.NORTH);
//
//        // Tạo CardLayout để chứa các giao diện khác nhau
//        cardLayout = new CardLayout();
//        mainPanel = new JPanel(cardLayout);
//
//        // Giao diện cho mỗi mục chọn
//        dsMonan = new Ds_monan();
//        JPanel mangVePanel = new Mang_ve(dsMonan);
//
//        JPanel taiChoPanel = new Tai_cho();
//
//        JPanel quanLyPanel = new JPanel();  // Giao diện quản lý tổng thể
////        JPanel lichSuDonHangPanel = new JPanel();  // Giao diện lịch sử đơn hàng
//        JPanel lichSuDonHangPanel = new LichSuDonHangPanel();
//        JPanel chinhSuaMenuPanel = new Chinh_sua_menu();  // Giao diện chỉnh sửa menu
//
//        // Thêm các giao diện vào CardLayout
//        mainPanel.add(mangVePanel, "Mang về");
//        mainPanel.add(taiChoPanel, "Tại chỗ");
//        mainPanel.add(quanLyPanel, "Quản lý");
//        mainPanel.add(lichSuDonHangPanel, "Lịch sử đơn hàng"); // Cập nhật tên panel
//        mainPanel.add(chinhSuaMenuPanel, "Chỉnh sửa menu");
//
//        // Thêm mainPanel (chứa các giao diện) vào giữa giao diện chính
//        this.add(mainPanel, BorderLayout.CENTER);
//
//        // Thêm ActionListener cho các nút lựa chọn để chuyển giao diện và đổi màu nút
//        mangVeButton.addActionListener(e -> switchPanel("Mang về", mangVeButton));
//        taiChoButton.addActionListener(e -> switchPanel("Tại chỗ", taiChoButton));
//
//        // Tạo JPopupMenu cho nút Quản lý
//        quanLyMenu = new JPopupMenu();
//        JMenuItem lichSuItem = new JMenuItem("Lịch sử đơn hàng"); // Đổi tên mục
//        JMenuItem chinhSuaMenuItem = new JMenuItem("Chỉnh sửa menu");
//        JMenuItem dangXuatItem = new JMenuItem("Đăng xuất");
//
//        // Thêm các mục vào popup menu
//        quanLyMenu.add(lichSuItem);
//        quanLyMenu.add(chinhSuaMenuItem);
//        quanLyMenu.add(dangXuatItem);
//
//        // Thêm MouseListener để hiển thị popup khi di chuột vào nút Quản lý
//        quanLyButton.addMouseListener(new MouseAdapter() {
//            @Override
//            public void mouseEntered(MouseEvent e) {
//                // Thiết lập kích thước của popup menu bằng kích thước của nút Quản lý
//                quanLyMenu.setPreferredSize(new Dimension(quanLyButton.getWidth(), quanLyMenu.getPreferredSize().height));
//
//                // Hiển thị popup menu dưới nút Quản lý
//                quanLyMenu.show(quanLyButton, 0, quanLyButton.getHeight());
//            }
//        });
//
//        // Xử lý các sự kiện khi chọn các mục trong menu quản lý
//        lichSuItem.addActionListener(e -> switchPanel("Lịch sử đơn hàng", quanLyButton)); // Cập nhật tên trong switchPanel
//        chinhSuaMenuItem.addActionListener(e -> switchPanel("Chỉnh sửa menu", quanLyButton));
//        dangXuatItem.addActionListener(e -> {
//            // Xử lý đăng xuất
//            // Đóng giao diện hiện tại
//            this.dispose();
//
//            // Hiển thị lại giao diện đăng nhập
//            LoginView loginView = new LoginView();
//            LoginController loginController = new LoginController(loginView);
//            loginView.setVisible(true);
//        });
//
//        // Hiển thị giao diện đầu tiên (Mang về)
//        switchPanel("Mang về", mangVeButton);
//
//        this.setVisible(true);
//    }
//
//    // Phương thức để chuyển giao diện và đổi màu nút
//    private void switchPanel(String panelName, JButton activeButton) {
//        // Chuyển giao diện
//        cardLayout.show(mainPanel, panelName);
//
//        // Đặt màu cho nút được chọn
//        activeButton.setBackground(Color.BLUE); // Đặt màu xanh cho nút được chọn
//        activeButton.setForeground(Color.WHITE); // Chữ màu trắng để dễ đọc
//
//        // Đặt màu mặc định cho các nút khác
//        if (activeButton != mangVeButton) {
//            mangVeButton.setBackground(null);
//            mangVeButton.setForeground(null);
//        }
//        if (activeButton != taiChoButton) {
//            taiChoButton.setBackground(null);
//            taiChoButton.setForeground(null);
//        }
//        if (activeButton != quanLyButton) {
//            quanLyButton.setBackground(null);
//            quanLyButton.setForeground(null);
//        }
//    }
//}
package view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import model.*;
import controller.*;

public class Giaodien extends JFrame {
    private CardLayout cardLayout;
    private JPanel mainPanel;
    private Ds_monan dsMonan;

    // Nút lựa chọn
    private JButton mangVeButton;
    private JButton taiChoButton;
    private JButton quanLyButton;

    // PopupMenu để hiển thị các mục con dưới nút Quản lý
    private JPopupMenu quanLyMenu;

    public Giaodien() {
        // Thiết lập khung chính
        this.setTitle("Giao diện chính");
        this.setSize(1000, 700);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setLayout(new BorderLayout());

        // Tạo các nút lựa chọn trên cùng với kiểu dáng đẹp hơn
        mangVeButton = createStyledButton("Mang về");
        taiChoButton = createStyledButton("Tại chỗ");
        quanLyButton = createStyledButton("Quản lý");

        // Panel chứa các nút lựa chọn
        JPanel menuPanel = new JPanel(new GridLayout(1, 3, 3, 3)); // Thêm khoảng cách giữa các nút
        menuPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Thêm khoảng trống xung quanh panel
        menuPanel.add(mangVeButton);
        menuPanel.add(taiChoButton);
        menuPanel.add(quanLyButton);

        // Thêm panel menu vào trên cùng của giao diện với màu nền khác
        menuPanel.setBackground(new Color(230, 230, 250)); // Màu nền nhạt
        this.add(menuPanel, BorderLayout.NORTH);

        // Tạo CardLayout để chứa các giao diện khác nhau
        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);
        mainPanel.setBackground(new Color(245, 245, 245)); // Màu nền chính của mainPanel

        // Giao diện cho mỗi mục chọn
        dsMonan = new Ds_monan();
        JPanel mangVePanel = new Mang_ve(dsMonan);
        JPanel taiChoPanel = new Tai_cho();
        JPanel quanLyPanel = new JPanel();
        JPanel lichSuDonHangPanel = new LichSuDonHangPanel();
        JPanel chinhSuaMenuPanel = new Chinh_sua_menu();

        // Thêm các giao diện vào CardLayout
        mainPanel.add(mangVePanel, "Mang về");
        mainPanel.add(taiChoPanel, "Tại chỗ");
        mainPanel.add(quanLyPanel, "Quản lý");
        mainPanel.add(lichSuDonHangPanel, "Lịch sử đơn hàng");
        mainPanel.add(chinhSuaMenuPanel, "Chỉnh sửa menu");

        // Thêm mainPanel (chứa các giao diện) vào giữa giao diện chính
        this.add(mainPanel, BorderLayout.CENTER);

        // Thêm ActionListener cho các nút lựa chọn để chuyển giao diện và đổi màu nút
        mangVeButton.addActionListener(e -> switchPanel("Mang về", mangVeButton));
        taiChoButton.addActionListener(e -> switchPanel("Tại chỗ", taiChoButton));

        // Tạo JPopupMenu cho nút Quản lý
        quanLyMenu = new JPopupMenu();
        JMenuItem lichSuItem = new JMenuItem("Lịch sử đơn hàng");
        JMenuItem chinhSuaMenuItem = new JMenuItem("Chỉnh sửa menu");
        JMenuItem dangXuatItem = new JMenuItem("Đăng xuất");

        // Thêm các mục vào popup menu
        quanLyMenu.add(lichSuItem);
        quanLyMenu.add(chinhSuaMenuItem);
        quanLyMenu.add(dangXuatItem);

        // Thêm MouseListener để hiển thị popup khi di chuột vào nút Quản lý
        quanLyButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                quanLyMenu.setPreferredSize(new Dimension(quanLyButton.getWidth(), quanLyMenu.getPreferredSize().height));
                quanLyMenu.show(quanLyButton, 0, quanLyButton.getHeight());
            }
        });

        // Xử lý các sự kiện khi chọn các mục trong menu quản lý
        lichSuItem.addActionListener(e -> switchPanel("Lịch sử đơn hàng", quanLyButton));
        chinhSuaMenuItem.addActionListener(e -> switchPanel("Chỉnh sửa menu", quanLyButton));
        dangXuatItem.addActionListener(e -> {
            this.dispose();
            LoginView loginView = new LoginView();
            LoginController loginController = new LoginController(loginView);
            loginView.setVisible(true);
        });

        // Hiển thị giao diện đầu tiên (Mang về)
        switchPanel("Mang về", mangVeButton);

        this.setVisible(true);
    }

    // Phương thức để tạo các nút với kiểu dáng đẹp
    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setFocusPainted(false); // Tắt viền nét khi chọn
        button.setBackground(new Color(100, 149, 237)); // Màu xanh nhạt
        button.setForeground(Color.WHITE); // Chữ màu trắng
        button.setFont(new Font("Arial", Font.BOLD, 16)); // Đặt font chữ
        button.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20)); // Thêm khoảng cách bên trong nút
        button.setCursor(new Cursor(Cursor.HAND_CURSOR)); // Đặt con trỏ chuột dạng tay khi di chuột vào nút
        return button;
    }

    // Phương thức để chuyển giao diện và đổi màu nút
    private void switchPanel(String panelName, JButton activeButton) {
        cardLayout.show(mainPanel, panelName);

        activeButton.setBackground(new Color(30, 144, 255)); // Đặt màu xanh dương đậm cho nút được chọn
        activeButton.setForeground(Color.WHITE);

        if (activeButton != mangVeButton) {
            mangVeButton.setBackground(new Color(100, 149, 237)); // Màu mặc định
            mangVeButton.setForeground(Color.WHITE);
        }
        if (activeButton != taiChoButton) {
            taiChoButton.setBackground(new Color(100, 149, 237));
            taiChoButton.setForeground(Color.WHITE);
        }
        if (activeButton != quanLyButton) {
            quanLyButton.setBackground(new Color(100, 149, 237));
            quanLyButton.setForeground(Color.WHITE);
        }
    }
}
