package view;

import javax.swing.*;
import java.awt.*;

public class ThongKe extends JPanel {
    public ThongKe() {
        // Thiết lập layout cho giao diện thống kê
        this.setLayout(new BorderLayout());
//              xem tong doanh thu

    }

}
