package view;

import model.*;
import controller.MangveController;
import javax.swing.*;
import java.awt.*;
import java.util.HashMap;
import java.sql.*;
import JDBCConnection.JConnection;

public class Mang_ve extends JPanel {
    private JButton checkoutButton;
    private JButton clearCartButton; // Nút xóa giỏ hàng
    private JList<String> orderList;
    private DefaultListModel<String> orderListModel;
    private JLabel totalLabel; 
    private Ds_monan dsMonan;
    private MangveController controller; 

    private JTextField searchField; 
    private JPanel menuPanel;

    public Mang_ve(Ds_monan dsMonan) {
        this.dsMonan = dsMonan;  
        this.controller = new MangveController(this); 

        this.setLayout(new BorderLayout(20, 20)); 

        // Thiết lập kích thước cho JPanel
        this.setPreferredSize(new Dimension(1000, 700));
        this.setBackground(new Color(245, 245, 245)); // Màu nền nhẹ cho toàn bộ JPanel

        // Tạo ô tìm kiếm và thêm vào panel
        searchField = new JTextField();
        searchField.setPreferredSize(new Dimension(400, 30));
        searchField.setFont(new Font("Arial", Font.PLAIN, 16));
        searchField.setForeground(new Color(50, 50, 50));
        searchField.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200), 1));
        searchField.addActionListener(e -> searchFoodItems(searchField.getText()));

        JPanel searchPanel = new JPanel();
        searchPanel.setLayout(new FlowLayout(FlowLayout.LEFT)); // Canh trái
        searchPanel.setBackground(new Color(245, 245, 245));
        searchPanel.add(new JLabel("Tìm kiếm món:"));
        searchPanel.add(searchField);
        this.add(searchPanel, BorderLayout.NORTH);

        // Tạo panel chứa danh sách món ăn với thanh cuộn
        menuPanel = new JPanel();
        menuPanel.setLayout(new BoxLayout(menuPanel, BoxLayout.Y_AXIS)); 
        menuPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Thêm padding
        menuPanel.setPreferredSize(new Dimension(500, 600)); 
        menuPanel.setMinimumSize(new Dimension(500, 100));

        JScrollPane scrollPane = new JScrollPane(menuPanel);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setPreferredSize(new Dimension(500, 600));

        this.add(scrollPane, BorderLayout.WEST); 

        // Phần giỏ hàng
orderListModel = new DefaultListModel<>();
orderList = new JList<>(orderListModel);
orderList.setFont(new Font("Arial", Font.PLAIN, 18)); // Tăng kích thước chữ của giỏ hàng

JPanel orderPanel = new JPanel(new BorderLayout());
orderPanel.setPreferredSize(new Dimension(400, 100)); 
orderPanel.setBackground(Color.WHITE); // Nền trắng cho giỏ hàng
orderPanel.add(new JScrollPane(orderList), BorderLayout.CENTER);

// Mục hiển thị tổng tiền
totalLabel = new JLabel("Tổng tiền: 0 VND", JLabel.CENTER);
totalLabel.setFont(new Font("Arial", Font.BOLD, 20));
totalLabel.setForeground(new Color(34, 139, 34)); // Màu xanh lá cho tổng tiền
orderPanel.add(totalLabel, BorderLayout.SOUTH);

// Nút thanh toán
checkoutButton = new JButton("Thanh toán");
checkoutButton.setFont(new Font("Arial", Font.BOLD, 18));
checkoutButton.setBackground(new Color(30, 144, 255)); // Màu xanh lam
checkoutButton.setForeground(Color.WHITE);
checkoutButton.setFocusPainted(false); // Không có đường viền khi chọn
checkoutButton.setPreferredSize(new Dimension(150, 40));
checkoutButton.addActionListener(e -> controller.checkout());
checkoutButton.addMouseListener(new java.awt.event.MouseAdapter() {
    public void mouseEntered(java.awt.event.MouseEvent evt) {
        checkoutButton.setBackground(new Color(70, 130, 180)); // Màu khi hover
    }
    public void mouseExited(java.awt.event.MouseEvent evt) {
        checkoutButton.setBackground(new Color(30, 144, 255)); // Trở lại màu ban đầu
    }
});

// Nút xóa giỏ hàng
clearCartButton = new JButton("Xóa");
clearCartButton.setFont(new Font("Arial", Font.BOLD, 18));
clearCartButton.setBackground(new Color(255, 69, 0)); // Màu đỏ
clearCartButton.setForeground(Color.WHITE);
clearCartButton.setFocusPainted(false); // Không có đường viền khi chọn
clearCartButton.setPreferredSize(new Dimension(150, 40));
clearCartButton.addActionListener(e -> clearCart()); // Gán sự kiện xóa giỏ hàng

// Thêm các nút thanh toán và xóa giỏ hàng vào panel giỏ hàng
JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
buttonPanel.add(checkoutButton);
buttonPanel.add(clearCartButton);
orderPanel.add(buttonPanel, BorderLayout.NORTH);

this.add(orderPanel, BorderLayout.EAST);

//        // Phần giỏ hàng
//        orderListModel = new DefaultListModel<>();
//        orderList = new JList<>(orderListModel);
//
//        JPanel orderPanel = new JPanel(new BorderLayout());
//        orderPanel.setPreferredSize(new Dimension(400, 100)); 
//        orderPanel.setBackground(Color.WHITE); // Nền trắng cho giỏ hàng
//        orderPanel.add(new JScrollPane(orderList), BorderLayout.CENTER);
//
//        // Mục hiển thị tổng tiền
//        totalLabel = new JLabel("Tổng tiền: 0 VND", JLabel.CENTER);
//        totalLabel.setFont(new Font("Arial", Font.BOLD, 20));
//        totalLabel.setForeground(new Color(34, 139, 34)); // Màu xanh lá cho tổng tiền
//        orderPanel.add(totalLabel, BorderLayout.SOUTH);
//
//        // Nút thanh toán
//        checkoutButton = new JButton("Thanh toán");
//        checkoutButton.setFont(new Font("Arial", Font.BOLD, 18));
//        checkoutButton.setBackground(new Color(30, 144, 255)); // Màu xanh lam
//        checkoutButton.setForeground(Color.WHITE);
//        checkoutButton.setFocusPainted(false); // Không có đường viền khi chọn
//        checkoutButton.setPreferredSize(new Dimension(150, 40));
//        checkoutButton.addActionListener(e -> controller.checkout());
//        checkoutButton.addMouseListener(new java.awt.event.MouseAdapter() {
//            public void mouseEntered(java.awt.event.MouseEvent evt) {
//                checkoutButton.setBackground(new Color(70, 130, 180)); // Màu khi hover
//            }
//            public void mouseExited(java.awt.event.MouseEvent evt) {
//                checkoutButton.setBackground(new Color(30, 144, 255)); // Trở lại màu ban đầu
//            }
//        });
//
//        // Nút xóa giỏ hàng
//        clearCartButton = new JButton("Xóa");
//        clearCartButton.setFont(new Font("Arial", Font.BOLD, 18));
//        clearCartButton.setBackground(new Color(255, 69, 0)); // Màu đỏ
//        clearCartButton.setForeground(Color.WHITE);
//        clearCartButton.setFocusPainted(false); // Không có đường viền khi chọn
//        clearCartButton.setPreferredSize(new Dimension(150, 40));
//        clearCartButton.addActionListener(e -> clearCart()); // Gán sự kiện xóa giỏ hàng
//
//        // Thêm các nút thanh toán và xóa giỏ hàng vào panel giỏ hàng
//        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
//        buttonPanel.add(checkoutButton);
//        buttonPanel.add(clearCartButton);
//        orderPanel.add(buttonPanel, BorderLayout.NORTH);
//
//        this.add(orderPanel, BorderLayout.EAST); 

        // Load tất cả món ăn khi bắt đầu
        loadFoodItems();
    }

    // Hàm xóa giỏ hàng
    private void clearCart() {
        controller.clearCart(); // Gọi phương thức trong controller để xóa giỏ hàng
    }

    // Hàm tìm kiếm món ăn trong cơ sở dữ liệu theo từ khóa
    private void searchFoodItems(String keyword) {
        try (Connection conn = JConnection.getJDBCConection()) {
            String query = "SELECT * FROM food WHERE LOWER(namefood) LIKE LOWER(?)";
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setString(1, "%" + keyword + "%");
            ResultSet rs = statement.executeQuery();
            
            menuPanel.removeAll(); // Xóa các món ăn cũ
            while (rs.next()) {
                String name = rs.getString("namefood");
                int price = rs.getInt("prices");
                
                // Tạo JButton cho mỗi món ăn
                JButton foodButton = new JButton(name + " - " + price + " VND");
                foodButton.setFont(new Font("Arial", Font.PLAIN, 16));
                foodButton.setBackground(new Color(240, 240, 240)); // Nền nhẹ cho nút
                foodButton.setForeground(new Color(50, 50, 50)); // Màu chữ đậm

                // Đặt kích thước cố định cho nút
                foodButton.setMaximumSize(new Dimension(480, 40));  

                foodButton.addActionListener(controller.createItemButtonListener(new Mon_an(name, price)));

                menuPanel.add(foodButton);
            }
            menuPanel.revalidate();
            menuPanel.repaint();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Hàm load tất cả món ăn từ cơ sở dữ liệu
    private void loadFoodItems() {
        try (Connection conn = JConnection.getJDBCConection()) {
            String query = "SELECT * FROM food";
            Statement statement = conn.createStatement();
            ResultSet rs = statement.executeQuery(query);

            menuPanel.removeAll(); // Xóa các món ăn cũ
            while (rs.next()) {
                String name = rs.getString("namefood");
                int price = rs.getInt("prices");
                
                // Tạo JButton cho mỗi món ăn
                JButton foodButton = new JButton(name + " - " + price + " VND");
                foodButton.setFont(new Font("Arial", Font.PLAIN, 16)); 
                foodButton.setBackground(new Color(240, 240, 240)); // Nền nhẹ cho nút
                foodButton.setForeground(new Color(50, 50, 50)); // Màu chữ đậm

                // Đặt kích thước cố định cho nút
                foodButton.setMaximumSize(new Dimension(500, 40)); 

                foodButton.addActionListener(controller.createItemButtonListener(new Mon_an(name, price)));

                menuPanel.add(foodButton);
            }
            menuPanel.revalidate();
            menuPanel.repaint();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Hàm cập nhật tổng tiền
    public void updateTotalLabel(int totalAmount) {
        totalLabel.setText("Tổng tiền: " + totalAmount + " VND");
    }

    // Hàm cập nhật danh sách giỏ hàng hiển thị
    public void updateOrderList(HashMap<String, Integer> cart) {
        orderListModel.clear(); // Xóa danh sách cũ
        for (String itemName : cart.keySet()) {
            int quantity = cart.get(itemName);
            orderListModel.addElement(itemName + " x " + quantity); // Hiển thị món ăn với số lượng
        }
    }
}
