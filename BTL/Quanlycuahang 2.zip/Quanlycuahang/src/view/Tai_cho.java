
package view;

import model.Ds_monan;
import model.Mon_an;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class Tai_cho extends JPanel {

    private JTextArea selectedFoodsArea;
    private JLabel totalAmountLabel;  // Label to show total amount
    private Ds_monan dsMonan;
    private DefaultListModel<String> foodListModel;
    private JList<String> foodList;
    private int selectedTableId = -1;
    private JButton[] tableButtons;  // To hold all table buttons for color change

    public Tai_cho() {
        setLayout(new BorderLayout());

        // Left Panel
        JPanel leftPanel = new JPanel();
        leftPanel.setLayout(new BorderLayout());

        // Search field
        JTextField searchField = new JTextField(20);
        searchField.setToolTipText("Tìm kiếm món ăn");

        // Food list
        dsMonan = new Ds_monan();
        Mon_an[] foodItems = dsMonan.getFoodItems();
        foodListModel = new DefaultListModel<>();
        for (Mon_an mon : foodItems) {
            foodListModel.addElement(mon.getName() + " - " + mon.getPrice() + " VND");
        }

        foodList = new JList<>(foodListModel);
        JScrollPane scrollPaneFoodList = new JScrollPane(foodList);
        scrollPaneFoodList.setPreferredSize(new Dimension(200, 200));

        // Selected foods area
        selectedFoodsArea = new JTextArea(10, 20);
        selectedFoodsArea.setEditable(false);
        JScrollPane scrollPaneSelectedFoods = new JScrollPane(selectedFoodsArea);

        // Total amount label
        totalAmountLabel = new JLabel("Tổng tiền: 0 VND");
        totalAmountLabel.setFont(new Font("Arial", Font.BOLD, 14));
        totalAmountLabel.setForeground(Color.RED);

        // Bottom Panel (Delete & Pay buttons)
        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new FlowLayout());

        JButton deleteButton = new JButton("Xóa");
        JButton payButton = new JButton("Thanh toán");

        // Delete button action
        deleteButton.addActionListener(e -> {
            if (selectedTableId != -1) {
                dsMonan.clearOrderedItems(selectedTableId);
                selectedFoodsArea.setText("Bàn " + selectedTableId + " đã xóa tất cả món ăn.");
                totalAmountLabel.setText("Tổng tiền: 0 VND"); // Reset total amount
                updateTableButtonColor(selectedTableId); // Reset table button color
            } else {
                JOptionPane.showMessageDialog(null, "Vui lòng chọn bàn trước khi xóa!");
            }
        });

        // Pay button action
        payButton.addActionListener(e -> {
            if (selectedTableId != -1) {
                String orderDate = java.time.LocalDate.now().toString();
                String totalAmount = dsMonan.getTotalAmount(selectedTableId);
                dsMonan.saveOrderToDatabase(orderDate, totalAmount);
                dsMonan.clearOrderedItems(selectedTableId);
                selectedFoodsArea.setText("Hóa đơn cho bàn " + selectedTableId + " đã được thanh toán.");
                totalAmountLabel.setText("Tổng tiền: 0 VND"); // Reset total amount
                updateTableButtonColor(selectedTableId); // Reset table button color
            } else {
                JOptionPane.showMessageDialog(null, "Vui lòng chọn bàn trước khi thanh toán!");
            }
        });

        bottomPanel.add(deleteButton);
        bottomPanel.add(payButton);

        // Panel container for selected foods area and buttons
        JPanel container = new JPanel(new BorderLayout());
        container.add(scrollPaneSelectedFoods, BorderLayout.CENTER);
        container.add(bottomPanel, BorderLayout.SOUTH);
        container.add(totalAmountLabel, BorderLayout.NORTH);  // Add total amount label to the top

        // Left split pane
        JSplitPane leftSplitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, scrollPaneFoodList, container);
        leftSplitPane.setDividerLocation(200);
        leftPanel.add(searchField, BorderLayout.NORTH);
        leftPanel.add(leftSplitPane, BorderLayout.CENTER);

        // Right Panel for tables
        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(new GridLayout(6, 2, 10, 10));

        // Create table buttons (from Table 1 to Table 12)
        tableButtons = new JButton[12];  // Array to hold all table buttons

        for (int i = 1; i <= 12; i++) {
            JButton tableButton = new JButton("Bàn " + i);
            tableButton.setPreferredSize(new Dimension(150, 150));
            tableButton.setBackground(Color.LIGHT_GRAY);
            tableButton.setOpaque(true);
            tableButton.setBorder(BorderFactory.createLineBorder(Color.BLACK));

            final int tableId = i;
            // When a table button is clicked
            tableButton.addActionListener(e -> {
                selectedTableId = tableId;
                String orderedItems = dsMonan.getOrderedItems(tableId);

                if (!orderedItems.isEmpty()) {
                    selectedFoodsArea.setText(orderedItems);  // Display ordered items
                    updateTotalAmount();  // Update total amount
                } else {
                    selectedFoodsArea.setText("Bàn " + tableId + " chưa có món ăn nào.");
                    totalAmountLabel.setText("Tổng tiền: 0 VND");  // Reset total amount
                }

                // Update the color of the table button
                updateTableButtonColor(tableId);
            });

            tableButtons[i - 1] = tableButton;  // Store button in array
            rightPanel.add(tableButton);  // Add table button to rightPanel
        }

        JScrollPane scrollPaneTables = new JScrollPane(rightPanel);
        scrollPaneTables.setPreferredSize(new Dimension(400, 0));

        // Main split pane combining leftPanel and rightPanel (table buttons)
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftPanel, scrollPaneTables);
        splitPane.setDividerLocation(400);
        add(splitPane, BorderLayout.CENTER);

        // Search field document listener to filter food list
        searchField.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                filterFoodList(searchField.getText());
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                filterFoodList(searchField.getText());
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                filterFoodList(searchField.getText());
            }
        });

        // Food list item click listener
        foodList.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                if (selectedTableId != -1) {
                    String selectedFood = foodList.getSelectedValue();
                    if (selectedFood != null) {
                        dsMonan.addOrderedItem(selectedTableId, selectedFood);
                        String orderedItems = dsMonan.getOrderedItems(selectedTableId);
                        selectedFoodsArea.setText(orderedItems);
                        updateTotalAmount();  // Update total amount after adding food
                        updateTableButtonColor(selectedTableId);  // Update table button color
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Vui lòng chọn bàn trước khi thêm món ăn!");
                }
            }
        });
    }

    // Function to update the total amount dynamically
    private void updateTotalAmount() {
        String totalAmount = dsMonan.getTotalAmount(selectedTableId);
        totalAmountLabel.setText("Tổng tiền: " + totalAmount + " VND");
    }

    // Function to filter food list based on search input
    private void filterFoodList(String query) {
        foodListModel.clear();
        Mon_an[] foodItems = dsMonan.getFoodItems();
        List<String> filteredItems = new ArrayList<>();
        for (Mon_an mon : foodItems) {
            if (mon.getName().toLowerCase().contains(query.toLowerCase())) {
                filteredItems.add(mon.getName() + " - " + mon.getPrice() + " VND");
            }
        }
        for (String item : filteredItems) {
            foodListModel.addElement(item);
        }
    }

    // Function to update the color of the table button based on the order status
    private void updateTableButtonColor(int tableId) {
        // Check if there are any items ordered for the selected table
        if (!dsMonan.getOrderedItems(tableId).isEmpty()) {
            tableButtons[tableId - 1].setBackground(Color.YELLOW);  // Change color if there are ordered items
        } else {
            tableButtons[tableId - 1].setBackground(Color.LIGHT_GRAY);  // Reset to default color
        }
    }
}
