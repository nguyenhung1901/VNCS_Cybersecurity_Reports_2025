package view;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import JDBCConnection.JConnection;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

public class LichSuDonHangPanel extends JPanel {
    private JTable orderTable;
    private DefaultTableModel tableModel;
    private JTable statsTable;
    private DefaultTableModel statsTableModel;
    private JTextField searchField;

    public LichSuDonHangPanel() {
        setLayout(new BorderLayout());

        // Tạo ô tìm kiếm
        JPanel searchPanel = new JPanel();
        searchField = new JTextField(20);
        searchField.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent e) {
                filterData(searchField.getText());
            }
        });

        JButton reloadButton = new JButton("Reload");
        reloadButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                loadOrderData();
                loadStatsData();
            }
        });
        searchPanel.add(reloadButton);

        searchPanel.add(new JLabel("Tìm kiếm theo ID Đơn hàng:"));
        searchPanel.add(searchField);
        add(searchPanel, BorderLayout.NORTH);

        // Cột của bảng
        String[] columnNames = {"ID Đơn hàng", "Ngày", "Tổng tiền", "Trạng thái"};

        // Tạo mô hình bảng
        tableModel = new DefaultTableModel(columnNames, 0);
        orderTable = new JTable(tableModel);

        // Tự động sắp xếp cột
        orderTable.setAutoCreateRowSorter(true);

        // Center align the columns: Ngày, Tổng tiền, Trạng thái
        centerAlignColumns();

        // Tạo JScrollPane chứa bảng và thêm vào JPanel
        JScrollPane scrollPane = new JScrollPane(orderTable);
        add(scrollPane, BorderLayout.CENTER);

        // Thêm nút Xóa ở dưới cùng
        JPanel buttonPanel = new JPanel();
        JButton deleteButton = new JButton("Xóa Đơn Hàng");
        deleteButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                deleteOrder();
            }
        });
        buttonPanel.add(deleteButton);
        add(buttonPanel, BorderLayout.SOUTH);

        // Bảng thống kê và biểu đồ
        JPanel statsPanel = new JPanel(new BorderLayout());
        String[] statsColumnNames = {"Tháng", "Tổng số đơn", "Tổng tiền"};
        statsTableModel = new DefaultTableModel(statsColumnNames, 0);
        statsTable = new JTable(statsTableModel);
        JScrollPane statsScrollPane = new JScrollPane(statsTable);
        statsPanel.add(statsScrollPane, BorderLayout.CENTER);

        // Tạo biểu đồ và thêm vào góc phải dưới
        JPanel chartPanel = createChartPanel();
        statsPanel.add(chartPanel, BorderLayout.SOUTH);

        add(statsPanel, BorderLayout.EAST);

        // Lấy dữ liệu từ cơ sở dữ liệu
        loadOrderData();
        loadStatsData();
    }

    private JPanel createChartPanel() {
        // Tạo dataset cho biểu đồ
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        String query = "SELECT MONTH(orderdate) AS month, SUM(totalamount) AS totalAmount FROM orderfood GROUP BY MONTH(orderdate) ORDER BY month";
        try (Connection conn = JConnection.getJDBCConection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                int month = rs.getInt("month");
                double totalAmount = rs.getDouble("totalAmount");
                dataset.addValue(totalAmount, "Tổng tiền", String.valueOf(month));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Lỗi kết nối cơ sở dữ liệu: " + e.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }

        // Tạo biểu đồ
        JFreeChart barChart = ChartFactory.createBarChart(
                "Thống kê tổng tiền theo tháng",
                "Tháng",
                "Tổng tiền",
                dataset,
                PlotOrientation.VERTICAL,
                false, true, false);

        return new ChartPanel(barChart);
    }

    private void loadOrderData() {
        String query = "SELECT idorder, orderdate, totalamount, payment FROM orderfood";
        try (Connection conn = JConnection.getJDBCConection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            // Dọn dẹp bảng trước khi cập nhật
            tableModel.setRowCount(0);

            while (rs.next()) {
                int idOrder = rs.getInt("idorder");
                Date orderDate = rs.getDate("orderdate");
                String totalAmount = rs.getString("totalamount");
                String payment = rs.getString("payment");

                // Thêm dòng mới vào bảng
                tableModel.addRow(new Object[]{idOrder, orderDate, totalAmount, payment});
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Lỗi kết nối cơ sở dữ liệu: " + e.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadStatsData() {
        String query = "SELECT MONTH(orderdate) AS month, COUNT(*) AS totalOrders, SUM(totalamount) AS totalAmount FROM orderfood GROUP BY MONTH(orderdate) ORDER BY month";
        try (Connection conn = JConnection.getJDBCConection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            // Dọn dẹp bảng trước khi cập nhật
            statsTableModel.setRowCount(0);

            while (rs.next()) {
                int month = rs.getInt("month");
                int totalOrders = rs.getInt("totalOrders");
                String totalAmount = rs.getString("totalAmount");

                // Thêm dòng mới vào bảng thống kê
                statsTableModel.addRow(new Object[]{month, totalOrders, totalAmount});
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Lỗi kết nối cơ sở dữ liệu: " + e.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void filterData(String query) {
        String searchQuery = "SELECT idorder, orderdate, totalamount, payment FROM orderfood WHERE idorder LIKE ?";
        try (Connection conn = JConnection.getJDBCConection();
             PreparedStatement stmt = conn.prepareStatement(searchQuery)) {

            String pattern = "%" + query + "%";
            stmt.setString(1, pattern);

            ResultSet rs = stmt.executeQuery();

            tableModel.setRowCount(0);
            while (rs.next()) {
                int idOrder = rs.getInt("idorder");
                Date orderDate = rs.getDate("orderdate");
                String totalAmount = rs.getString("totalamount");
                String payment = rs.getString("payment");
                tableModel.addRow(new Object[]{idOrder, orderDate, totalAmount, payment});
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void deleteOrder() {
        // Lấy ID đơn hàng được chọn
        int selectedRow = orderTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn đơn hàng để xóa", "Lỗi", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int idOrder = (int) tableModel.getValueAt(selectedRow, 0);

        // Hỏi người dùng xác nhận xóa
        int confirmation = JOptionPane.showConfirmDialog(this,
                "Bạn có chắc chắn muốn xóa đơn hàng ID: " + idOrder + "?", "Xác nhận xóa",
                JOptionPane.YES_NO_OPTION);

        if (confirmation == JOptionPane.YES_OPTION) {
            String deleteQuery = "DELETE FROM orderfood WHERE idorder = ?";
            try (Connection conn = JConnection.getJDBCConection();
                 PreparedStatement stmt = conn.prepareStatement(deleteQuery)) {

                stmt.setInt(1, idOrder);
                int rowsAffected = stmt.executeUpdate();

                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(this, "Đơn hàng đã được xóa thành công", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
                    // Cập nhật lại dữ liệu trong bảng
                    loadOrderData();
                    loadStatsData();
                } else {
                    JOptionPane.showMessageDialog(this, "Không tìm thấy đơn hàng để xóa", "Lỗi", JOptionPane.ERROR_MESSAGE);
                }

            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Lỗi khi xóa đơn hàng: " + e.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void centerAlignColumns() {
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        orderTable.getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
        orderTable.getColumnModel().getColumn(1).setCellRenderer(centerRenderer); // Ngày
        orderTable.getColumnModel().getColumn(2).setCellRenderer(centerRenderer); // Tổng tiền
        orderTable.getColumnModel().getColumn(3).setCellRenderer(centerRenderer); // Trạng thái
    }
}