package test;

import view.LoginView;
import controller.LoginController;

public class Test{
    public static void main(String[] args) {
        // Khởi tạo giao diện đăng nhập
        LoginView loginView = new LoginView();

        // Tạo controller để gắn action listener cho giao diện
        LoginController loginController = new LoginController(loginView);
    }
}
