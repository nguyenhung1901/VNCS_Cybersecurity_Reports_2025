package JDBCConnection;
import java.sql.*;

public class JConnection {
    public static Connection getJDBCConection() {
        final String url = "jdbc:mysql://localhost:3306/oop"; // URL của cơ sở dữ liệu
        final String user = "root";  // Tên người dùng
        final String password = "12345678";  // Mật khẩu

        try {
            // Tải driver MySQL
            Class.forName("com.mysql.cj.jdbc.Driver");
            // Kết nối tới cơ sở dữ liệu
            return DriverManager.getConnection(url, user, password);
        } catch (SQLException e) {
            System.out.println("Kết nối cơ sở dữ liệu thất bại: " + e.getMessage());
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            System.out.println("Không tìm thấy driver JDBC: " + e.getMessage());
            e.printStackTrace();
        }
        return null; // Nếu có lỗi, trả về null
    }
}
