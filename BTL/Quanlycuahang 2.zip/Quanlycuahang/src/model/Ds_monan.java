
package model;

import JDBCConnection.JConnection;
import java.sql.*;
import java.util.*;

public class Ds_monan {
    private Mon_an[] monAnArray;  // Mảng chứa danh sách món ăn
    private Map<Integer, List<String>> orderedItemsMap = new HashMap<>();  // Lưu trữ các món đã đặt theo bàn

    public Ds_monan() {
        loadFoodItemsFromDatabase();  // Tải danh sách món ăn từ cơ sở dữ liệu khi khởi tạo đối tượng
    }

    public Mon_an[] getFoodItems() {
        return monAnArray;  // Trả về mảng món ăn
    }

    // Lấy danh sách món ăn từ cơ sở dữ liệu
    private void loadFoodItemsFromDatabase() {
        try (Connection conn = JConnection.getJDBCConection()) {
            String query = "SELECT * FROM food";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            List<Mon_an> foodItems = new ArrayList<>();

            while (rs.next()) {
                String name = rs.getString("namefood");  // Tên món ăn
                int price = rs.getInt("prices");  // Giá món ăn
                foodItems.add(new Mon_an(name, price));  // Thêm món ăn vào danh sách
            }

            monAnArray = foodItems.toArray(new Mon_an[0]);  // Chuyển đổi thành mảng
        } catch (SQLException e) {
            e.printStackTrace();  // Xử lý lỗi nếu có
        }
    }

    // Phương thức tính tổng tiền các món ăn đã chọn cho bàn
    public String getTotalAmount(int tableId) {
        List<String> orderedItems = orderedItemsMap.getOrDefault(tableId, new ArrayList<>());
        int totalAmount = 0;

        for (String item : orderedItems) {
            // Giả sử tên món ăn có định dạng "Tên món - Giá tiền"
            String[] parts = item.split(" - ");
            if (parts.length == 2) {
                try {
                    totalAmount += Integer.parseInt(parts[1].replace(" VND", "").trim());
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                }
            }
        }

        return String.valueOf(totalAmount);  // Trả về tổng tiền dưới dạng chuỗi
    }

    // Phương thức lưu hóa đơn vào cơ sở dữ liệu
    public void saveOrderToDatabase(String orderDate, String totalAmount) {
        String sql = "INSERT INTO orderfood (orderdate, totalamount, payment) VALUES (?, ?, ?)";

        try (Connection conn = JConnection.getJDBCConection();
             PreparedStatement statement = conn.prepareStatement(sql)) {

            statement.setString(1, orderDate);   // Gán giá trị orderdate
            statement.setString(2, totalAmount); // Gán giá trị totalamount
            statement.setString(3, "Đã thanh toán"); // Gán giá trị payment

            statement.executeUpdate(); // Thực thi câu lệnh insert
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Lấy danh sách món đã đặt của một bàn
    public String getOrderedItems(int tableId) {
        StringBuilder items = new StringBuilder();
        List<String> orderedFoods = orderedItemsMap.get(tableId);
        if (orderedFoods != null) {
            for (String food : orderedFoods) {
                items.append(food).append("\n");
            }
        }
        return items.toString();
    }

    // Thêm món ăn vào danh sách đã đặt cho bàn
    public void addOrderedItem(int tableId, String food) {
        orderedItemsMap.computeIfAbsent(tableId, k -> new ArrayList<>()).add(food);
    }

    // Xóa tất cả món ăn đã đặt của một bàn
    public void clearOrderedItems(int tableId) {
        orderedItemsMap.remove(tableId);
    }

    // Cập nhật lại danh sách món ăn từ cơ sở dữ liệu
    public void updateFoodItems() {
        loadFoodItemsFromDatabase();
    }

    // Phương thức thêm món vào cơ sở dữ liệu
    public void addFoodToDatabase(String name, int price) {
        String sql = "INSERT INTO food (namefood, prices) VALUES (?, ?)";

        try (Connection conn = JConnection.getJDBCConection();
             PreparedStatement statement = conn.prepareStatement(sql)) {

            statement.setString(1, name);  // Tên món ăn
            statement.setInt(2, price);    // Giá món ăn

            statement.executeUpdate();  // Thực thi câu lệnh insert
        } catch (SQLException e) {
            e.printStackTrace();
        }

        // Sau khi thêm món, cập nhật lại danh sách món ăn
        updateFoodItems();
    }
}
