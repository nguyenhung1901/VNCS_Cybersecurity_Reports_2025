
package model;

public class Mon_an {
    private String name;
    private int price;

    public Mon_an(String name, int price) {
        this.name = name;
        this.price = price;
    }

    public String getName(){
        return name;
    }

    public int getPrice() {
        return price;
    }
}
